package org.sid.entities;

import com.sun.istack.NotNull;
import jdk.nashorn.internal.runtime.logging.Logger;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.transaction.Transactional;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Entity
public class Produit implements Serializable {

    @Id
    @GeneratedValue
    private Long Id;
    @NotNull
    @Size(min=4, max=20)
    private String designation;
    @DecimalMin(value = "1")
    private double prix;
    @DecimalMin("1")
    private int quantite;

    public Produit() { }

    public Produit(String designation, double prix, int quantite) {
        this.designation = designation;
        this.prix = prix;
        this.quantite = quantite;
    }

    public void setId(Long Id) { this.Id = Id; }

    public Long getId() {
        return Id;
    }

    public String getDesignation() { return designation; }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }
}
