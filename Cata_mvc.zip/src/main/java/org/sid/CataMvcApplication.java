package org.sid;

import org.sid.dao.ProduitRepository;
import org.sid.entities.Produit;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class CataMvcApplication {

    public static void main(String[] args) {

        ApplicationContext ctx = SpringApplication.run(CataMvcApplication.class, args);
        ProduitRepository produitDao = ctx.getBean(ProduitRepository.class);

       /* produitDao.save(new Produit("RF458", 1500, 20));
        produitDao.save(new Produit("MN489", 2000, 70));
        produitDao.save(new Produit("SO785", 800, 120));
        produitDao.save(new Produit("AP526", 4700, 10));
        produitDao.save(new Produit("FK419", 900, 220));
        produitDao.save(new Produit("RP723", 8500, 8));
        produitDao.save(new Produit("CX235", 1985, 79));
        produitDao.save(new Produit("MB197", 1900, 80));*/

    }

}
